package com.projeto.henrique.unimarket;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class informacoesServico extends AppCompatActivity {
    private DatabaseReference database;
    private ArrayList<Usuario> user = new ArrayList<>();
    private String tipagem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacoes_servico);
        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
        stars.getDrawable(2).setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_ATOP);
        ratingBar.setIsIndicator(true);
        Intent intent = getIntent();
        final Anuncio servico = (Servico) intent.getSerializableExtra("nome");
        final String tipo = (String)intent.getStringExtra("tipo");
        tipagem = tipo;
        final Intent intent2 = new Intent(this ,  Avaliar.class);
        final Intent intent3 = new Intent(this ,  informacaoUsuario.class);
        final Intent intent4 = new Intent(this, informacoesServico.class);
        ratingBar.setRating(servico.getAvaliacao());
        ArrayList<String> info = new ArrayList<>();
        info.add("Informações do serviço");
        info.add(servico.toString());
        info.add("Informações do anunciante");
        info.add("Curso: "+servico.getVendedor().getCurso());
        info.add("Telefone: "+servico.getVendedor().getTelefone());
        info.add("E-mail: "+servico.getVendedor().getLogin().replace("A", "@").replace("P","."));
        info.add("Favoritar serviço");
        info.add("Avaliar Produto");
        final String email = info.get(5);
        final String email2 = email.substring(7, email.length());
        consultarUser((Servico)servico);
        ListView lista = (ListView) findViewById(R.id.line1);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, info);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==2){
                    intent3.putExtra("nome",user.get(0));
                    startActivity(intent3);
                }
                if(position==4){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("http://api.whatsapp.com/send?phone="+servico.getVendedor().getTelefone() +
                            "&text="+"Olá,me chamo "+MainMenu.retornaUsuario().getNome()+" e estou interessado no produto "+servico.getNome()));
                    startActivity(intent);
                }
                if(position==5){
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    Uri data = Uri.parse("mailto:"+email2+"?subject=Produto do UniMarket" + "&body=Estou interessado no seu produto" );
                    intent.setData(data);
                    startActivity(intent);
                }
                if(position==6){
                    Toast.makeText(getApplicationContext(), "Favoritado", Toast.LENGTH_SHORT).show();
                    try {
                        servico.favoritar(MainMenu.retornaUsuario());
                        intent4.putExtra("nome", servico);
                        intent4.putExtra("tipo", tipagem);
                        startActivity(intent4);
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }
                    catch (RuntimeException re){
                        Toast.makeText(getApplicationContext(), re.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                if(position==7){
                    intent2.putExtra("nome",  servico);
                    startActivity(intent2);
                }
            }
        });
    }
    public void consultarUser(final Servico servico){
        database = FirebaseDatabase.getInstance().getReference("Usuario/");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot Snapshot) {
                try {
                    for (DataSnapshot dataSnapshot : Snapshot.getChildren()) {
                        Usuario value = dataSnapshot.getValue(Usuario.class);
                        if((servico.getVendedor().getLogin().equals(value.getLogin()))) {
                            user.add(value);
                        }
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(tipagem.equals("main")) {
            Intent intent = new Intent(this, MainMenu.class);
            intent.putExtra("nome", MainMenu.retornaUsuario());
            startActivity(intent);
        }
        if(tipagem.equals("procurar")){
            Intent intent = new Intent(this, ProcurarServicos.class);
            intent.putExtra("nome", MainMenu.retornaUsuario());
            startActivity(intent);
        }
        if(tipagem.equals("favoritado")){
            Intent intent = new Intent(this, VerMeusFavoritados.class);
            intent.putExtra("nome", MainMenu.retornaUsuario());
            startActivity(intent);
        }
    }
}
