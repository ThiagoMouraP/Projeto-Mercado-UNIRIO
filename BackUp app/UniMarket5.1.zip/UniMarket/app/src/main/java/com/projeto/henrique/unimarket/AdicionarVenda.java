package com.projeto.henrique.unimarket;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;

public class AdicionarVenda extends AppCompatActivity {
    private DatabaseReference database;
    private Produto produto;
    private Servico servico;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_venda);
        String[] tipo = {"Produto", "Serviço"};
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tipo);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        String[] tipo2 = {"Presencial", "A distância"};
        final Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tipo2);
        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter2);
    }
    public void CadastrarAnuncio(View view) {
        LinearLayout linha = findViewById(R.id.linha);
        LinearLayout linha2 = findViewById(R.id.linha2);
        LinearLayout linha3 = findViewById(R.id.linha3);
        EditText n = (EditText) findViewById(R.id.nome);
        String nome = n.getText().toString();
        EditText l = (EditText) findViewById(R.id.login);
        String login = l.getText().toString();
        EditText s = (EditText) findViewById(R.id.senha);
        String senha = s.getText().toString();
        EditText ns = (EditText) findViewById(R.id.confsenha);
        String confsenha = ns.getText().toString();
        EditText nu = (EditText) findViewById(R.id.numero);
        String numero = nu.getText().toString();
        if(!isCampoVazio(nome)||!isCampoVazio(login)||!isCampoVazio(senha)||!isCampoVazio(confsenha)||!isCampoVazio(numero)) {
            double preco = Double.parseDouble(numero);
            Spinner spinner = (Spinner) findViewById(R.id.spinner);
            String curso = spinner.getSelectedItem().toString();
            ArrayList<String> tag = new ArrayList<>();
            tag.add(senha);
            tag.add(confsenha);
            tag.add(nome);
            linha.setVisibility(View.GONE);
            //Realiza a
            if (curso.equals("Produto")) {
                Anuncio venda = new Produto(Principal.retornaUsuario(), preco, nome, login, tag, true);
                produto = (Produto) venda;
                linha2.setVisibility(View.VISIBLE);
            } else {
                Anuncio venda = new Servico(Principal.retornaUsuario(), preco, nome, login, tag, true);
                servico = (Servico) venda;
                linha3.setVisibility(View.VISIBLE);
            }
        }
        else{
            mostrarDialogo();
        }
    }
    public void CadastrarProduto(View view) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        EditText qtd = (EditText) findViewById(R.id.quantidade);
        String quant = qtd.getText().toString();
        if(!isCampoVazio(quant)) {
            int quantidade = Integer.parseInt(quant);
            produto.setQuantidade(quantidade);
            database = FirebaseDatabase.getInstance().getReference();
            database.child("Produto").child(gerarId(produto.getNome(), Principal.retornaUsuario().getLogin())).setValue(produto);
            Toast.makeText(getApplicationContext(), "Cadastrado", Toast.LENGTH_SHORT).show();
            voltar();
        }
        else{
            mostrarDialogo();
        }
    }
    public void CadastrarServico(View view) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        LinearLayout linha4 = findViewById(R.id.linha4);
        Spinner spinner2 = (Spinner) findViewById(R.id.spinner2);
        servico.setPresencial(retornarPresencial(spinner2.getSelectedItem().toString()));
        if(servico.isPresencial()){
            linha4.setVisibility(View.VISIBLE);
        }
        else{
            servico.setHorario(" ");
            cadastrarServicoBanco();
        }

    }
    public static boolean retornarPresencial(String presencial){
        if(presencial.equals("Presencial")){
            return true;
        }
        else{
            return false;
        }
    }
    public void CadastrarHorario(View view) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        EditText hour = (EditText) findViewById(R.id.horario);
        String horario = hour.getText().toString();
        if(!isCampoVazio(horario)) {
            servico.setHorario(horario);
            cadastrarServicoBanco();
        }
        else{
            mostrarDialogo();
        }

    }
    public void cadastrarServicoBanco() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        database = FirebaseDatabase.getInstance().getReference();
        database.child("Servico").child(gerarId(servico.getNome(), Principal.retornaUsuario().getLogin())).setValue(servico);
        Toast.makeText(getApplicationContext(), "Cadastrado", Toast.LENGTH_SHORT).show();
        voltar();
    }

    public static String gerarId(String a1, String a2) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest algorithm = MessageDigest.getInstance("MD5");
        byte messageDigest[] = algorithm.digest((a1+a2).getBytes("UTF-8"));
        StringBuilder hexString = new StringBuilder();
        for (byte b : messageDigest) {
            hexString.append(String.format("%02X", 0xFF & b));
        }
         return hexString.toString();
    }
    public void voltar(){
        Intent intent = new Intent(this, Principal.class);
        intent.putExtra("nome", Principal.retornaUsuario());
        startActivity(intent);
    }
    public boolean isCampoVazio(String valor) {
        boolean resposta = (TextUtils.isEmpty(valor) || valor.trim().isEmpty());
        return resposta;
    }
    public void mostrarDialogo(){
        AlertDialog.Builder aviso = new AlertDialog.Builder(this);
        aviso.setTitle(R.string.title_aviso);
        aviso.setMessage(R.string.message_aviso);
        aviso.setNeutralButton(R.string.neutral_button, null);
        aviso.show();
    }
}
