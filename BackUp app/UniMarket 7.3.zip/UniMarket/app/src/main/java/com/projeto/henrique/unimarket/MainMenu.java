package com.projeto.henrique.unimarket;

import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainMenu extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private ArrayList<String> nomes = new ArrayList<>();
    private ArrayList<Anuncio> anuncios = new ArrayList<>();
    private DatabaseReference database;
    private ArrayList<Drawable> imagem = new ArrayList<>();
    private ArrayList<Anuncio> prod= new ArrayList<>();
    private static Usuario u;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Intent intent = getIntent();
        Usuario user = (Usuario) intent.getSerializableExtra("nome");
        u = user;
        TextView n = (TextView) findViewById(R.id.apresentacao);
        String nome = user.getNome();
        String[] veri = nome.split(" ");
        if(veri.length>1){
            nome = veri[0];
        }
        String bv = "Bem vindo, "+nome;
        n.setText(bv);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        final Intent intent2 = new Intent(this, MainActivity.class);
        final Intent intent3 = new Intent(this, informacaoProduto.class);
        final Intent intent4 = new Intent(this, informacoesServico.class);
        nomes.add("Feed de anuncios");
        imagem.add(getResources().getDrawable(R.drawable.lista));
        consultarProdutos();
        consultarServicos();
        ListView lista = (ListView) findViewById(R.id.line1);
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, nomes);
        CustomListAdapter adapter=new CustomListAdapter(this, nomes, imagem);
        try {
            lista.setAdapter(adapter);
            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (position == 0) {
                        Toast.makeText(getApplicationContext(), "Isto é apenas um sinal, não é um anúncio. Por que você clicou aqui?", Toast.LENGTH_SHORT).show();
                    } else if (position <= prod.size()) {
                        //A imagem é retirada do objeto para que não haja bugs quando este por passado
                        //de uma tela para a outra
                        anuncios.get(position - 1).setImagem("");
                        intent3.putExtra("nome", anuncios.get(position - 1));
                        startActivity(intent3);
                    } else {
                        anuncios.get(position - 1).setImagem("");
                        intent4.putExtra("nome", anuncios.get(position - 1));
                        startActivity(intent4);
                    }
                }
            });
        }catch (IndexOutOfBoundsException iobe){
            Toast.makeText(getApplicationContext(), iobe.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_gerenciarVendas) {
            irGerencia();
        } else if (id == R.id.nav_procuarServicos) {
            irServicos();
        } else if (id == R.id.nav_procurarProdutos) {
            irProduto();
        } else if (id == R.id.nav_procurarUsuario) {
            irListaUsuario();
        } else if (id == R.id.nav_perfil) {
            irSeuPerfil();
        } else if (id == R.id.nav_procurarFavoritado) {
            irSeuFavoritado();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void irProduto(){
        Intent intent = new Intent(this, ProcurarProdutos.class);
        startActivity(intent);
    }
    public void irServicos(){
        Intent intent = new Intent(this, ProcurarServicos.class);
        startActivity(intent);
    }
    public void irSeuPerfil(){
        Intent intent = new Intent(this, AtualizaUsuario.class);
        startActivity(intent);
    }
    public void irSeuFavoritado(){
        Intent intent = new Intent(this, VerMeusFavoritados.class);
        startActivity(intent);
    }
    public void irListaUsuario(){
        Intent intent = new Intent(this, ListaUsuario.class);
        startActivity(intent);
    }
    public void irGerencia(){
        Intent intent = new Intent(this, GerenciarVendas.class);
        startActivity(intent);
    }
    public void consultarProdutos(){
        database = FirebaseDatabase.getInstance().getReference("Produto/");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot Snapshot) {
                try {
                    for (DataSnapshot dataSnapshot : Snapshot.getChildren()) {
                        Produto value = dataSnapshot.getValue(Produto.class);
                        if(!(value.getVendedor().getNome().equals(MainMenu.retornaUsuario().getNome()))) {
                            if(value.isDisponibilidade()) {
                                nomes.add(value.toString());
                                anuncios.add(value);
                                prod.add(value);
                                if(value.isTemImagem()) {
                                    Drawable drawable =
                                            new BitmapDrawable(getResources(), GerenciarVendas.StringToBitMap(value.getImagem()));
                                    imagem.add(drawable);
                                }
                                else{
                                    imagem.add(getResources().getDrawable(R.drawable.duvida));
                                }

                            }
                        }
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                catch (OutOfMemoryError out){
                    Toast.makeText(getApplicationContext(), out.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });
    }
    public void consultarServicos(){
        database = FirebaseDatabase.getInstance().getReference("Servico/");
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot Snapshot) {
                try {
                    for (DataSnapshot dataSnapshot : Snapshot.getChildren()) {
                        Servico value = dataSnapshot.getValue(Servico.class);
                        if(!(value.getVendedor().getNome().equals(MainMenu.retornaUsuario().getNome()))) {
                            if(value.isDisponibilidade()) {
                                nomes.add(value.toString());
                                anuncios.add(value);
                                if(value.isTemImagem()) {
                                    Drawable drawable =
                                            new BitmapDrawable(getResources(), GerenciarVendas.StringToBitMap(value.getImagem()));
                                    imagem.add(drawable);
                                }
                                else{
                                    imagem.add(getResources().getDrawable(R.drawable.duvida));
                                }

                            }
                        }
                    }
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                catch (OutOfMemoryError out){
                    Toast.makeText(getApplicationContext(), out.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });
    }
    public static Usuario retornaUsuario(){
        return u;
    }
}
